from django.db import models

# Create your models here.
class Skills(models.Model):
    teacher_id = models.CharField(max_length=50)
    skill = models.CharField(max_length=200) 
    skill_level = models.CharField(max_length=200)
    language = models.CharField(max_length=200) 
     
    def __unicode__(self):
        return '/%s/' % self.title

    def get_absolute_url(self):
        return '/%s/' % self.title
