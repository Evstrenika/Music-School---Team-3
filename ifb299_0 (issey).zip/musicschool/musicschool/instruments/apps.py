from django.apps import AppConfig

class InstrumentsConfig(AppConfig):
    name = 'instruments'
