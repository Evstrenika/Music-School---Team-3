"""
Package for musicschool.
"""
