from django.shortcuts import render
from django.template.response import TemplateResponse
from students.models import Students

# Create your views here.
def students(request):
    data = Students.objects.all()
    return TemplateResponse(request,'pages/students.html', {"data" : data}) # curly braces dictionary list

