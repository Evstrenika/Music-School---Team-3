from django.db import models

# Create your models here.
class Instruments(models.Model):
    instrument_id = models.CharField(max_length=50)
    name = models.CharField(max_length=200)
    description = models.TextField(max_length=3000)
    condition = models.CharField(max_length=200)
    hired = models.BooleanField(default=False)
    
    def __unicode__(self):
        return '/%s/' % self.title

    def get_absolute_url(self):
        return '/%s/' % self.title

'''
####
# 
# pass in terminal
#
#
##

python manage.py makemigrations
python manage.py migrate

'''

