from django.apps import AppConfig


class PreferencesConfig(AppConfig):
    name = 'preferences'
